// backend/controllers/eventController.js

const Event = require("../models/Event");

// GET: All Events
exports.getAllEvents = async (req, res) => {
  try {
    const events = await Event.find().populate("registeredUsers", "name email");
    res.json(events);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST: Create New Event (for testing only)
exports.createEvent = async (req, res) => {
  try {
    const event = await Event.create(req.body);
    res.status(201).json(event);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// POST: Register for an event
exports.registerForEvent = async (req, res) => {
  const eventId = req.params.id;
  const userId = req.user._id;

  try {
    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    if (event.registeredUsers.includes(userId)) {
      return res.status(400).json({ message: "Already registered" });
    }

    if (event.registeredUsers.length >= event.totalSeats) {
      return res.status(400).json({ message: "No seats left" });
    }

    event.registeredUsers.push(userId);
    await event.save();

    res.json({ message: "Successfully registered", event });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET: Registered events for logged-in user
exports.getRegisteredEvents = async (req, res) => {
  const userId = req.user._id;

  try {
    const events = await Event.find({ registeredUsers: userId });
    res.json(events);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
