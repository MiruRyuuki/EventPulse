// routes/eventRoutes.js

const express = require("express");
const router = express.Router();
const {
  getAllEvents,
  createEvent,
  registerForEvent,
  getRegisteredEvents
} = require("../controllers/eventController");

// ✅ Double-check this line!
const { protect } = require("../middleware/authMiddleware");

// Public routes
router.get("/", getAllEvents);
router.post("/", createEvent);

// Protected routes
router.post("/register/:id", protect, registerForEvent);
router.get("/registered", protect, getRegisteredEvents);

module.exports = router;
