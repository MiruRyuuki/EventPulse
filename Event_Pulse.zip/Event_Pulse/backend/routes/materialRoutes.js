// backend/routes/materialRoutes.js

const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const {
  uploadMaterial,
  getMaterials
} = require("../controllers/materialController");

// Create folder if not exists
const materialDir = path.join(__dirname, "../uploads/materials");
if (!fs.existsSync(materialDir)) {
  fs.mkdirSync(materialDir, { recursive: true });
}

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, materialDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const upload = multer({ storage });

// Routes
router.post("/upload", upload.single("file"), uploadMaterial);
router.get("/", getMaterials);


module.exports = router;
